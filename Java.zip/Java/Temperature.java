import java.util.Scanner;

public class Temperature {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

        System.out.print("Enter the temperature: ");
        int temperature = input.nextInt();

        if (temperature < 50)
        System.out.println("It's cold.");
        else if (temperature < 80)
        System.out.println("It's nice.");
        else
        System.out.println("It's hot.");

    }
}