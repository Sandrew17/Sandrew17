public class Demo {
    public static void main(String[] args){
        int x = 2;
        System.out.println("The value of x at the start is " + x);

        int y = ++x;
        System.out.println("The value of y is " + y);

        int z = x++;
        System.out.println("The value of z is " + z);

        int i = --x;
        System.out.println("The value of i is " + i);

        int j = x--;
        System.out.println("The value of j is " + j);

    }
} 